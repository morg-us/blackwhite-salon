import { Menu, X, User, LogOut, Moon, Sun, Globe } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { AuthModal } from "@/components/AuthModal";
import { ProfileModal } from "@/components/ProfileModal";
import { useUser, useClerk } from "@clerk/react";
import { useT, LANGUAGES } from "@/lib/translations";

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const langMenuRef = useRef<HTMLDivElement>(null);

  const { setIsAuthModalOpen, setIsProfileModalOpen, siteContent, theme, setTheme, language, setLanguage } = useStore();
  const { user, isSignedIn } = useUser();
  const { signOut } = useClerk();
  const t = useT();

  const displayName = user?.fullName ?? user?.firstName ?? user?.emailAddresses?.[0]?.emailAddress ?? "";
  const displayEmail = user?.emailAddresses?.[0]?.emailAddress ?? "";
  const avatarUrl = user?.imageUrl;
  const initials = displayName
    ? displayName.split(" ").map((w: string) => w[0]).join("").toUpperCase().slice(0, 2)
    : "?";

  const currentLang = LANGUAGES.find(l => l.code === language) ?? LANGUAGES[0];

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) setIsUserMenuOpen(false);
      if (langMenuRef.current && !langMenuRef.current.contains(e.target as Node)) setIsLangOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const navLinks = [
    { name: t("nav_home"), href: "#hero" },
    { name: t("nav_about"), href: "#staff" },
    { name: t("nav_pricing"), href: "#pricing" },
    { name: t("nav_gallery"), href: "#gallery" },
    { name: t("nav_store"), href: "#products" },
    { name: t("nav_contact"), href: "#contact" },
  ];

  const scrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const handleLogout = async () => {
    setIsUserMenuOpen(false);
    setIsMobileMenuOpen(false);
    await signOut();
  };

  const toggleTheme = () => setTheme(theme === "dark" ? "light" : "dark");

  return (
    <>
      <nav className={`sticky top-0 z-50 w-full transition-all duration-300 ${isScrolled ? "bg-background/95 backdrop-blur-md shadow-sm" : "bg-transparent"}`}>
        <div className="container mx-auto px-4 md:px-8 h-16 md:h-20 flex items-center justify-between">

          {/* Logo */}
          <div className="flex items-center gap-2 md:gap-3">
            <div className="w-8 h-8 md:w-10 md:h-10 rounded-full border border-primary/50 flex items-center justify-center bg-card overflow-hidden shrink-0 relative">
              <span
                className="font-serif font-bold text-sm md:text-lg text-primary absolute inset-0 flex items-center justify-center transition-opacity duration-500"
                style={{ opacity: siteContent.logoImageUrl ? 0 : 1 }}
              >
                BW
              </span>
              {siteContent.logoImageUrl && (
                <img
                  key={siteContent.logoImageUrl}
                  src={siteContent.logoImageUrl}
                  alt="Logo"
                  className="w-full h-full object-cover absolute inset-0"
                  style={{ animation: "fadeInLogo 0.5s ease-in-out" }}
                />
              )}
            </div>
            <span className={`font-bold text-base md:text-xl tracking-wider uppercase transition-colors ${isScrolled ? "text-foreground" : "text-white"}`}>
              Black White
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-4 lg:gap-6">
            <div className="flex gap-4 lg:gap-6">
              {navLinks.map(link => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={e => scrollTo(e, link.href)}
                  className={`text-sm font-medium hover:text-primary transition-colors ${isScrolled ? "text-foreground/80" : "text-white/90"}`}
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* Theme toggle */}
            <button
              onClick={toggleTheme}
              title={theme === "dark" ? t("theme_light") : t("theme_dark")}
              className={`p-2 rounded-full hover:bg-white/10 transition-colors ${isScrolled ? "text-foreground/70 hover:bg-muted" : "text-white/80"}`}
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Language selector */}
            <div className="relative" ref={langMenuRef}>
              <button
                onClick={() => setIsLangOpen(v => !v)}
                className={`flex items-center gap-1 px-2 py-1.5 rounded-full text-xs font-semibold transition-colors hover:bg-white/10 ${isScrolled ? "text-foreground/70 hover:bg-muted" : "text-white/80"}`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{currentLang.flag} {currentLang.code.toUpperCase()}</span>
              </button>
              {isLangOpen && (
                <div className="absolute right-0 top-9 w-36 bg-card border border-border rounded-xl shadow-xl py-1 z-50">
                  {LANGUAGES.map(lang => (
                    <button
                      key={lang.code}
                      onClick={() => { setLanguage(lang.code); setIsLangOpen(false); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted/50 transition-colors text-left ${language === lang.code ? "text-primary font-semibold" : "text-foreground"}`}
                    >
                      <span>{lang.flag}</span>
                      <span>{lang.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Auth */}
            {isSignedIn ? (
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => setIsUserMenuOpen(v => !v)}
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm transition-transform hover:scale-105 ring-2 ring-transparent hover:ring-primary/50 overflow-hidden"
                  style={{ backgroundColor: "#b84d5b" }}
                  data-testid="button-user-menu"
                >
                  {avatarUrl
                    ? <img src={avatarUrl} alt={initials} className="w-full h-full object-cover" />
                    : initials
                  }
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 top-12 w-56 bg-card border border-border rounded-xl shadow-xl py-1 z-50">
                    <div className="px-4 py-3 border-b border-border">
                      <p className="font-semibold text-sm truncate">{displayName}</p>
                      <p className="text-xs text-muted-foreground truncate">{displayEmail}</p>
                    </div>
                    <button
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted/50 transition-colors text-left"
                      onClick={() => { setIsUserMenuOpen(false); setIsProfileModalOpen(true); }}
                    >
                      <User className="w-4 h-4 text-primary" /> {t("nav_profile")}
                    </button>
                    <div className="border-t border-border mt-1 pt-1">
                      <button
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-destructive/10 text-destructive transition-colors text-left"
                        onClick={handleLogout}
                      >
                        <LogOut className="w-4 h-4" /> {t("nav_logout")}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                className={`hover:bg-primary/20 hover:text-primary ${isScrolled ? "text-foreground" : "text-white"}`}
                onClick={() => setIsAuthModalOpen(true)}
              >
                {t("nav_login")}
              </Button>
            )}
          </div>

          {/* Mobile Right Side */}
          <div className="flex md:hidden items-center gap-1">
            {/* Theme toggle mobile */}
            <button
              onClick={toggleTheme}
              className={`p-2 ${isScrolled ? "text-foreground/70" : "text-white/80"}`}
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {isSignedIn ? (
              <button
                onClick={() => setIsMobileMenuOpen(v => !v)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs overflow-hidden"
                style={{ backgroundColor: "#b84d5b" }}
              >
                {avatarUrl
                  ? <img src={avatarUrl} alt={initials} className="w-full h-full object-cover" />
                  : initials
                }
              </button>
            ) : (
              <button
                className={`p-1.5 ${isScrolled ? "text-foreground" : "text-white"}`}
                onClick={() => setIsAuthModalOpen(true)}
                aria-label={t("nav_login")}
              >
                <User className="w-5 h-5" />
              </button>
            )}

            <button
              className={`p-1.5 ${isScrolled ? "text-foreground" : "text-white"}`}
              onClick={() => setIsMobileMenuOpen(v => !v)}
              aria-label="Menü"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 w-full bg-background/98 backdrop-blur-md border-b border-border shadow-xl z-40">
            <div className="px-4 py-2">
              {navLinks.map(link => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={e => scrollTo(e, link.href)}
                  className="flex items-center py-3 text-base font-medium text-foreground border-b border-border/50 last:border-0 hover:text-primary transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* Mobile language + theme */}
            <div className="px-4 py-3 border-t border-border/50 flex items-center gap-2">
              {LANGUAGES.map(lang => (
                <button
                  key={lang.code}
                  onClick={() => { setLanguage(lang.code); }}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${language === lang.code ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/40"}`}
                >
                  {lang.flag} {lang.code.toUpperCase()}
                </button>
              ))}
            </div>

            <div className="border-t border-border px-4 py-3">
              {isSignedIn ? (
                <>
                  <div className="flex items-center gap-3 mb-3 pb-3 border-b border-border/50">
                    <div className="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center text-white font-bold text-sm shrink-0" style={{ backgroundColor: "#b84d5b" }}>
                      {avatarUrl ? <img src={avatarUrl} alt={initials} className="w-full h-full object-cover" /> : initials}
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{displayName}</p>
                      <p className="text-xs text-muted-foreground truncate">{displayEmail}</p>
                    </div>
                  </div>
                  <button className="w-full flex items-center gap-3 py-2.5 text-sm text-foreground hover:text-primary transition-colors"
                    onClick={() => { setIsMobileMenuOpen(false); setIsProfileModalOpen(true); }}>
                    <User className="w-4 h-4 text-primary" /> {t("nav_profile")}
                  </button>
                  <button className="w-full flex items-center gap-3 py-2.5 text-sm text-destructive hover:bg-destructive/10 rounded-md transition-colors mt-1"
                    onClick={handleLogout}>
                    <LogOut className="w-4 h-4" /> {t("nav_logout")}
                  </button>
                </>
              ) : (
                <Button
                  className="w-full bg-[#b84d5b] hover:bg-[#b84d5b]/90 text-white"
                  onClick={() => { setIsMobileMenuOpen(false); setIsAuthModalOpen(true); }}
                >
                  {t("nav_login_register")}
                </Button>
              )}
            </div>
          </div>
        )}
      </nav>

      <AuthModal />
      <ProfileModal />
    </>
  );
}
